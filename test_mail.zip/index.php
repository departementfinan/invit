<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $recaptchaResponse = $_POST['g-recaptcha-response'];
    $secretKey = '6LdzhU4qAAAAABpmbZjAcV1M_XD1Cv_Czzwce-jf';
    $response = file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=$secretKey&response=$recaptchaResponse");
    $responseKeys = json_decode($response, true);

    if (intval($responseKeys["success"]) !== 1) {
        echo 'Échec de la vérification reCAPTCHA.';
    } else {
        // Rediriger vers votre site principal
        header('Location: index.html');
        exit;
    }
}
?>
